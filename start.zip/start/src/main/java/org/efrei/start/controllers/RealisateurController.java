package org.efrei.start.controllers;

import org.efrei.start.models.Realisateur;
import org.efrei.start.services.RealisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/realisateurs")
public class RealisateurController {

    private final RealisateurService service;

    @Autowired
    public RealisateurController(RealisateurService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Realisateur>> findAll() {
        return new ResponseEntity<>(service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Realisateur> findById(@PathVariable Long id) {
        Realisateur realisateur = service.findById(id);
        if (realisateur == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(realisateur, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable Long id) {
        Realisateur realisateur = service.findById(id);
        if (realisateur == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Realisateur realisateur) {
        service.create(realisateur);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Realisateur realisateur) {
        Realisateur existingRealisateur = service.findById(id);
        if (existingRealisateur == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.update(id, realisateur);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
