package org.efrei.start.models;
import jakarta.persistence.*;
import org.efrei.start.global.Categorie;
import org.efrei.start.global.Categorie;

@Entity
public class Film {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "titre", nullable = false, length = 50)
    private String titre;

    @Column(name = "resume", nullable = false, length = 1000)
    private String resume;

    @Column(name = "personnage", nullable = false, length = 200)
    private String personnage;

    @Enumerated
    private Categorie categorie;


    public Film(String titre, String resume, String personnage, Categorie categorie) {
        this.titre = titre;
        this.resume = resume;
        this.personnage = personnage;
        this.categorie = categorie;
    }

    public Film() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public String getPersonnage() {
        return personnage;
    }

    public void setPersonnage(String personnage) {
        this.personnage = personnage;
    }

    @OneToOne
    private Acteur acteur;


    public Categorie getCategory() {
        return categorie;
    }

    public void setCategory(Categorie categorie) {
        this.categorie = categorie;
    }
}