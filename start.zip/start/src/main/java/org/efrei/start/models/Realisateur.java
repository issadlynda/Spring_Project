package org.efrei.start.models;

import jakarta.persistence.*;

@Entity
public class Realisateur {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Utilise IDENTITY pour une colonne auto-incrémentée
    private Long id;

    @Column(name = "nom", nullable = false, length = 255)
    private String nom;

    @Column(name = "date_naissance", nullable = false)
    private java.util.Date dateNaissance;

    @Column(name = "nationalite", length = 100)
    private String nationalite;

    @Column(name = "films")
    private String films; // Utilise une chaîne pour stocker les films

    @Column(name = "genre_prefer", length = 100)
    private String genrePrefer;

    @Column(name = "recompenses")
    private String recompenses;

    @Column(name = "site_web")
    private String siteWeb;

    // Constructeurs
    public Realisateur(String nom, java.util.Date dateNaissance, String nationalite, String films, String genrePrefer, String recompenses, String siteWeb) {
        this.nom = nom;
        this.dateNaissance = dateNaissance;
        this.nationalite = nationalite;
        this.films = films;
        this.genrePrefer = genrePrefer;
        this.recompenses = recompenses;
        this.siteWeb = siteWeb;
    }

    public Realisateur() {}

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public java.util.Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(java.util.Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public String getNationalite() {
        return nationalite;
    }

    public void setNationalite(String nationalite) {
        this.nationalite = nationalite;
    }

    public String getFilms() {
        return films;
    }

    public void setFilms(String films) {
        this.films = films;
    }

    public String getGenrePrefer() {
        return genrePrefer;
    }

    public void setGenrePrefer(String genrePrefer) {
        this.genrePrefer = genrePrefer;
    }

    public String getRecompenses() {
        return recompenses;
    }

    public void setRecompenses(String recompenses) {
        this.recompenses = recompenses;
    }

    public String getSiteWeb() {
        return siteWeb;
    }

    public void setSiteWeb(String siteWeb) {
        this.siteWeb = siteWeb;
    }
}
