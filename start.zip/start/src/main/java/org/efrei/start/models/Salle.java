package org.efrei.start.models;

import jakarta.persistence.*;

@Entity
public class Salle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "nom", nullable = false, length = 255)
    private String nom;

    @Column(name = "capacite", nullable = false)
    private int capacite;

    @Column(name = "type", length = 100)
    private String type;

    @Column(name = "equipements")
    private String equipements;

    @Column(name = "projection_3d")
    private boolean projection3D;

    @Column(name = "adresse", length = 255)
    private String adresse;

    @Column(name = "telephone", length = 20)
    private String telephone;

    // Constructeurs
    public Salle(String nom, int capacite, String type, String equipements, boolean projection3D, String adresse, String telephone) {
        this.nom = nom;
        this.capacite = capacite;
        this.type = type;
        this.equipements = equipements;
        this.projection3D = projection3D;
        this.adresse = adresse;
        this.telephone = telephone;
    }

    public Salle() {
    }

    // Getters et Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEquipements() {
        return equipements;
    }

    public void setEquipements(String equipements) {
        this.equipements = equipements;
    }

    public boolean isProjection3D() {
        return projection3D;
    }

    public void setProjection3D(boolean projection3D) {
        this.projection3D = projection3D;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
}
