package org.efrei.start.services;

import org.efrei.start.models.Film;
import org.efrei.start.repositories.FilmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilmService {

    private final FilmRepository repository;

    @Autowired
    public FilmService(FilmRepository repository) {
        this.repository = repository;
    }

    public List<Film> findAll() {
        System.out.println(repository.findAll());
        return repository.findAll();
    }

    public void create(Film film) {
        repository.save(film);
    }

    public Film findById(String id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void update(String id, Film film) {
        Film updateFilm = findById(id);
        if (updateFilm != null) {
            updateFilm.setTitre(film.getTitre());
            updateFilm.setResume(film.getResume());
            updateFilm.setPersonnage(film.getPersonnage());
            updateFilm.setCategory(film.getCategory());
            repository.save(updateFilm);
        }
    }
}
