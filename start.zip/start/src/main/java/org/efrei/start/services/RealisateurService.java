package org.efrei.start.services;

import org.efrei.start.models.Realisateur;
import org.efrei.start.repositories.RealisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RealisateurService {

    private final RealisateurRepository repository;

    @Autowired
    public RealisateurService(RealisateurRepository repository) {
        this.repository = repository;
    }

    public List<Realisateur> findAll() {
        return repository.findAll();
    }

    public void create(Realisateur realisateur) {
        repository.save(realisateur);
    }

    public Realisateur findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    public void update(Long id, Realisateur realisateur) {
        Realisateur updateRealisateur = findById(id);
        if (updateRealisateur != null) {
            updateRealisateur.setNom(realisateur.getNom());
            updateRealisateur.setDateNaissance(realisateur.getDateNaissance());
            updateRealisateur.setNationalite(realisateur.getNationalite());
            updateRealisateur.setFilms(realisateur.getFilms());
            updateRealisateur.setGenrePrefer(realisateur.getGenrePrefer());
            updateRealisateur.setRecompenses(realisateur.getRecompenses());
            updateRealisateur.setSiteWeb(realisateur.getSiteWeb());
            repository.save(updateRealisateur);
        }
    }
}
