package org.efrei.start.services;

import org.efrei.start.models.Salle;
import org.efrei.start.repositories.SalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SalleService {

    private final SalleRepository repository;

    @Autowired
    public SalleService(SalleRepository repository) {
        this.repository = repository;
    }

    public List<Salle> findAll() {
        return repository.findAll();
    }

    public void create(Salle salle) {
        repository.save(salle);
    }

    public Salle findById(int id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteById(int id) {
        repository.deleteById(id);
    }

    public void update(int id, Salle salle) {
        Salle existingSalle = findById(id);
        if (existingSalle != null) {
            existingSalle.setNom(salle.getNom());
            existingSalle.setCapacite(salle.getCapacite());
            existingSalle.setType(salle.getType());
            existingSalle.setEquipements(salle.getEquipements());
            existingSalle.setProjection3D(salle.isProjection3D());
            existingSalle.setAdresse(salle.getAdresse());
            existingSalle.setTelephone(salle.getTelephone());
            repository.save(existingSalle);
        }
    }
}
